import 'package:flutter/material.dart';
import 'package:perpus/models/book_model.dart';

class BookController with ChangeNotifier{
  final List<Book> _books = [
    Book(id: '1',
     title: 'Azzamine',
      description: 'Azzam melakukan berbagai cara untuk mendekati Jasmine. Lewat perilaku dan tutur katanya yang lembut, dia berusaha untuk meluluhkan hati Jasmine. Walaupun Jasmine berusaha menjauhinya, namun sosok Azzam terus saja menghantui pikirannya.', 
      stock: 10, 
      imagrUrl: 'https://image.popmama.com/content-images/post/20240822/7%20Fakta%20dan%20Sinopsis%20Film%20Azzamine%20%288%29-k4qgJfKFQcjY9B2WwodULA7FqyjchkVL.jpg?width=600&height=auto', 
      publisher: 'Bukune Keatif Cipta', 
      author: 'Sophie Aulia'
      ),
  ]
}