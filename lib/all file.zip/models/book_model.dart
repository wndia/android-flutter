class Book {
  final String id;
  final String title;
  final String description;
  final int stock;
  final String imagrUrl;
  final String publisher;
  final String author;

  Book({
    required this.id,
    required this.title,
    required this.description,
    required this.stock,
    required this.imagrUrl,
    required this.publisher,
    required this.author,
  });
}
